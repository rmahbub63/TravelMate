package com.example.mahbub.travelmateui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.mahbub.travelmateui.adapter.HorizontalAdapterPopularPlace;
import com.example.mahbub.travelmateui.model.PopularPlacesModel;

import java.util.ArrayList;

public class SearchPlaceManualActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<PopularPlacesModel> popularList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_search_place);
        // For Recycler View
        popularList = new ArrayList<>();

        popularList.add(new PopularPlacesModel(R.drawable.tour_plan_logo, "Bangladesh", 4.5f, "220 Review"));
        popularList.add(new PopularPlacesModel(R.drawable.tour_plan_logo, "Dhaka", 4.5f, "120 Review"));
        popularList.add(new PopularPlacesModel(R.drawable.tour_plan_logo, "Chandpur", 5.0f, "200 Review"));
        popularList.add(new PopularPlacesModel(R.drawable.tour_plan_logo, "Khulna", 4.5f, "210 Review"));

        recyclerView = findViewById(R.id.horizontal_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(new HorizontalAdapterPopularPlace(this, popularList));
    }
}
